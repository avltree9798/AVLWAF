<?php
/**
 * Created by PhpStorm.
 * User: avltree
 * Date: 18/09/18
 * Time: 15:09
 */

namespace AVLFirewall;

class Firewall
{
    const VERSION = 1;

    public function processRequest($requests = [])
    {
        if (environment('FIREWALL_ENABLED')) {
            $verdict = craftRequest(array_merge($requests, [
                'url' => $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
            ]), [
                'Authorization: ' . base64_encode(environment('CLIENT_KEY') . ':' . environment('CLIENT_SECRET') . ':' . getClientIp())
            ]);
            if ( ! $verdict->success) {
                http_response_code(401);
                echo $verdict->message;
                die();
            }
        }

        return true;
    }
}