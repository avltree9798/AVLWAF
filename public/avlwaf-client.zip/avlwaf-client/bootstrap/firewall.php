<?php
/**
 * Created by PhpStorm.
 * User: avltree
 * Date: 18/09/18
 * Time: 15:08
 */
use AVLFirewall\Firewall;

$firewall = new Firewall();
return $firewall;