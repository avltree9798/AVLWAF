<?php
/**
 * Created by PhpStorm.
 * User: avltree
 * Date: 18/09/18
 * Time: 15:07
 */
define('WAF_START', microtime(true));
require_once __DIR__ . '/bootstrap/autoload.php';

/**
 * @var \AVLFirewall\Firewall $firewall
 */
$firewall = require_once __DIR__ . '/bootstrap/firewall.php';
$requests = $_REQUEST;
return $firewall->processRequest($requests);
