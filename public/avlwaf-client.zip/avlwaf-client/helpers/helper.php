<?php
if ( ! function_exists('env')) {
    /**
     * @param mixed $key
     * @return string|array
     */
    function environment($key = null)
    {
        $envs = explode(PHP_EOL, file_get_contents(__DIR__ . '/../.env'));
        $environments = [];
        foreach ($envs as $env) {
            $env = explode('=', $env);
            $value = $env[1];
            if ($value === 'true') {
                $value = true;
            } else {
                if ($value === 'false') {
                    $value = false;
                }
            }
            $environments[$env[0]] = $value;
        }
        if ($key === null) {
            return $environments;
        } else {
            return $environments[$key];
        }
    }
}

if ( ! function_exists('craftRequest')) {
    /**
     * @param array $requests
     * @param array $headers
     * @return \stdClass
     */
    function craftRequest($requests = [], $headers = [])
    {
        $requestBody = '';
        foreach ($requests as $key => $request) {
            $requestBody .= $key . '=' . $request . '&';
        }
        $requestBody = substr($requestBody, 0, -1);
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, environment('SERVER_FIREWALL'));
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $requestBody);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($curl);

        return json_decode($result);
    }
}

if ( ! function_exists('getClientIp')) {
    /**
     * @return string
     */
    function getClientIp()
    {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP')) {
            $ipaddress = getenv('HTTP_CLIENT_IP');
        } else {
            if (getenv('HTTP_X_FORWARDED_FOR')) {
                $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
            } else {
                if (getenv('HTTP_X_FORWARDED')) {
                    $ipaddress = getenv('HTTP_X_FORWARDED');
                } else {
                    if (getenv('HTTP_FORWARDED_FOR')) {
                        $ipaddress = getenv('HTTP_FORWARDED_FOR');
                    } else {
                        if (getenv('HTTP_FORWARDED')) {
                            $ipaddress = getenv('HTTP_FORWARDED');
                        } else {
                            if (getenv('REMOTE_ADDR')) {
                                $ipaddress = getenv('REMOTE_ADDR');
                            } else {
                                $ipaddress = 'UNKNOWN';
                            }
                        }
                    }
                }
            }
        }

        return $ipaddress;
    }
}